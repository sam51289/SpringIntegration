package demo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController 
@RequestMapping(value="/emp")
public class EmpController {
	static List<Emp> list = new ArrayList<>();
	
	public EmpController() {
		Emp e = new Emp();
		e.setEmpno(1); e.setEname("a");e.setSalary(111);
		list.add(e);
	}
	@PostMapping( consumes = MediaType.APPLICATION_JSON_VALUE, 
			produces=MediaType.APPLICATION_JSON_VALUE)
	public Emp Create(@RequestBody Emp e){
		System.out.println(" in create .. " + e);
		list.add(e);
		return e;
	}
	@GetMapping(produces={MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	public List<Emp> list(){
		System.out.println("in list " + list.size());
		return list;
	}
	
	@PutMapping(consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity update(@RequestBody Emp e){
	
			Optional<Emp> emp = list.stream().filter((e1)-> e1.getEmpno() == e.getEmpno()).findFirst();
			System.out.println(emp.get());
			if (emp.isPresent())
			{
			Emp em  = emp.get();
			em.setEname(e.getEname());
			em.setSalary(e.getSalary());
			return ResponseEntity.noContent().build();
		}
		else
			return ResponseEntity.notFound().build();
	}
	@DeleteMapping(value="/{empno}")
	public  ResponseEntity delete(@PathVariable(name="empno") int empno)
	{
		System.out.println(" delete " + empno);
		if (list.removeIf( (e) -> e.getEmpno() == empno))
		{
			return ResponseEntity.noContent().build();
		}
		else
		{
			return ResponseEntity.notFound().build();
		}
	}
	
	
}
