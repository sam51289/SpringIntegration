package controllers;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value="/first")
public class First {
	@GetMapping
	public String method1(){
		return "<h1>Method1 - Get</h1>";
	}
	@PostMapping
	public String method2(){
		return "<h1>Method2 - Post</h1>";
	}
	@PutMapping
	public String method3(){
		System.out.println("put invoked ... ");		
		return "<h1>Method3 - PUT</h1>";
	}
	@DeleteMapping
	public String method4(){
		return "<h1>Method4 - Delete</h1>";
	}
	@PatchMapping
	public String method5(){
		return "<h1>Method5 - Patch</h1>";
	}
	
}
