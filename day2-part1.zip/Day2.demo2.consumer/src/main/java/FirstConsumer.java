import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class FirstConsumer {

	public static void main(String[] args) {
		String url = "http://localhost:8080/first";
	 RestTemplate template = new RestTemplate();
	 
	 System.out.println(template.getForEntity(url ,String.class).getBody());
	 System.out.println(template.postForEntity(url,null, String.class));
	 template.put(url,null);
	 template.delete(url);
	 System.out.println(template.patchForObject(url, null,String.class));

	}

}
