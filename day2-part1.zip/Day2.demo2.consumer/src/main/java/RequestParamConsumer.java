import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class RequestParamConsumer {
	public static void main(String[] args) {
		String url = "http://localhost:8080/rp";
	 RestTemplate template = new RestTemplate();
	 
	 ResponseEntity<String> restr = template.getForEntity(url+"/hello?nm=aaa", String.class);
	 System.out.println(restr.getBody());
	 restr = template.getForEntity(url+"/divide?n1=1000&n2=200", String.class);
	 System.out.println(restr.getBody());
	 

	}
}
