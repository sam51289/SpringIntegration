package demo;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@SpringBootApplication
@EnableScheduling
@EnableAsync
public class Application {

	public static void main(String[] args) throws InterruptedException, ExecutionException {

		ConfigurableApplicationContext ctx = SpringApplication.run(Application.class, args);
		Simple s = ctx.getBean(Simple.class);
		for(int i = 0; i< 5;i++){
				s.m1(i);
		}
		
		SimpleAsync asy = ctx.getBean(SimpleAsync.class);
		asy.method5();
		System.out.println("after invoking method 5...." );
		Future<String> fstr = asy.method6();
		System.out.println("after invoking method 6..." );
		
	
		Future<String> fstr1 = asy.method6();
		System.out.println("after invoking method 6..." );
		System.out.println(fstr.get());
		System.out.println(fstr1.get());
	}
	
	@Bean
	@Primary
	public TaskExecutor taskexe(){
		ThreadPoolTaskExecutor txe = new ThreadPoolTaskExecutor();
		txe.setCorePoolSize(1);
		txe.setMaxPoolSize(5);
		txe.setQueueCapacity(5);
		return txe;
	}

}
