package demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.task.TaskExecutor;
import org.springframework.stereotype.Component;

@Component
public class Simple {
	@Autowired
	private TaskExecutor taskexecutor;
	
	public Simple() {
		System.out.println("Simple Constructor");
	}
	
	public void m1( int i ){
		Runnable r = ()->{
			System.out.println(i + " in start ." + Thread.currentThread().getName());
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println("in end run method ..");
		};
		taskexecutor.execute(r);
	}
	
}
