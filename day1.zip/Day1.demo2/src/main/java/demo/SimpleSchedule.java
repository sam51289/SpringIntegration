package demo;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class SimpleSchedule {

	@Scheduled(initialDelay=1000, fixedRate=3000)
	public void m1(){
		System.out.println("in m1 ..." + new Date() + ", " + Thread.currentThread().getName());
		};
	
	@Scheduled(cron="*/10 * * * * *")
	public void m2(){
			System.out.println("in m2 ..." + new Date() + ", " + Thread.currentThread().getName());
	};

}
