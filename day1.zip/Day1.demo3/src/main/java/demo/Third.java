package demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value="/invoke")
public class Third {
	@GetMapping
	public String process(){
		String s = "";
		for (int i = 0; i< 50;i++)
	{
			s+= "current i = "+ i + "<br/>";
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
		return "<h1>"+ s + "</h1>";
	}

}
