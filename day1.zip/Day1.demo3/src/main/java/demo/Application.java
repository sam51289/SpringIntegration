package demo;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@SpringBootApplication
@EnableAsync
public class Application {

	public static void main(String[] args) {
		ConfigurableApplicationContext ctx = SpringApplication.run(Application.class, args);
		MyService ser = ctx.getBean(MyService.class);
		Future<String> fs = ser.getdata();
		for (int i = 0;i< 100000;i++){
			if ((i%10)==0)
				{
				System.out.print(".");
				try {
					String str = fs.get(1, TimeUnit.MILLISECONDS);
					System.out.println("Data: " +str);
					break;
				} catch (InterruptedException | ExecutionException | TimeoutException e) {
					System.out.println("waiting for data ..");
				}
				}
		}
		
	}
	
	
	@Bean
	@Primary
	public TaskExecutor taskexe(){
		ThreadPoolTaskExecutor txe = new ThreadPoolTaskExecutor();
		txe.setCorePoolSize(2);
		txe.setMaxPoolSize(5);
		txe.setQueueCapacity(2);
		return txe;
	}

}
