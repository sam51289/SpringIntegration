package demo1;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

class Lab3Helper implements Callable<Integer>
{
	int i = 0, j = 0;

	public Lab3Helper(int i, int j) {
		this.i = i; 		this.j = j;
	}
	
	@Override
	public Integer call() throws Exception {
		System.out.println("in call with" + i + ", " + j);
		Thread.sleep(1000);
		return i+j;
	}
}
public class Lab3 {

	public static void main(String[] args) throws InterruptedException, ExecutionException, TimeoutException {
		Lab3Helper helper = new Lab3Helper(10,1000);
		Future<Integer> future = Executors.newSingleThreadExecutor().submit(helper);
		System.out.println("after future calllllll");
		System.out.println("Sum = " + future.get(1500, TimeUnit.MILLISECONDS));
	}
}
