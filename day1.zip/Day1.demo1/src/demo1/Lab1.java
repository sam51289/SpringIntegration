package demo1;

import java.util.Scanner;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

class Lab1Helper implements Runnable
{
	
	public void run() {
		System.out.println("in start of Lab1Helper run method ..");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("in end of Lab1Helper run method ..");
	}
	}
public class Lab1 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a number to start ..");
		scanner.nextInt();
		
	//	Executor executor = Executors.newFixedThreadPool(5);
		// Create a  threads depending on requests, if existing use them, but max limit is 5 threads
		Executor executor = Executors.newCachedThreadPool();
		// Create a  threads depending on requests, if existing use them
		for (int i  = 0; i<5000;i++){
			executor.execute(new Lab1Helper());
		}

	}

}
