package demo1;

import java.util.Date;
import java.util.Scanner;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

class Lab2Helper implements Runnable
{
	
	public void run() {
		System.out.println("in start of Lab2Helper run method .." + new Date());
		try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("in end of Lab2Helper run method .." + new Date());
	}
	}
public class Lab2 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a number to start ..");
		scanner.nextInt();
		
		ScheduledExecutorService executor  = Executors.newScheduledThreadPool(1);
	//	executor.scheduleAtFixedRate(new Lab2Helper(), 1, 5, TimeUnit.SECONDS);
		// at fixed start time + interval -> may have multiple threads running for same task concurrently
		
		executor.scheduleWithFixedDelay(new Lab2Helper(), 1, 10, TimeUnit.SECONDS);
		// end of task+ interval
	/*	for (int i  = 0; i<5000;i++){
			executor.execute(new Lab2Helper());
		}*/

	}

}
